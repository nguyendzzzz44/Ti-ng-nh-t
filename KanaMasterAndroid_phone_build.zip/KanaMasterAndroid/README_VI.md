# Kana Master — dự án Android miễn phí

Đây là **mã nguồn khởi đầu** cho app học Hiragana/Katakana với giao diện tối kiểu anime.

## Có gì trong bản đầu
- Bảng 46 Hiragana và 46 Katakana cơ bản
- Nghe phát âm qua bộ đọc tiếng Nhật (TTS) trên Android
- Đánh dấu chữ đã học
- Trắc nghiệm nhiều lựa chọn, tính điểm
- Vùng tập viết bằng ngón tay
- Màn hình tiến độ
- Không cần tài khoản, không cần internet sau khi đã cài (phát âm phụ thuộc dữ liệu TTS cài trên máy)

## Cách tạo APK trên máy tính
1. Cài Android Studio từ trang chính thức: https://developer.android.com/studio
2. Giải nén file ZIP này.
3. Mở Android Studio → **Open** → chọn thư mục `KanaMasterAndroid`.
4. Chờ Gradle Sync hoàn tất. Nếu Android Studio hỏi cài Android SDK 35, hãy đồng ý.
5. Chọn **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Bấm **locate** ở thông báo hoàn tất để tìm APK, rồi chuyển APK sang điện thoại và cài đặt.
7. Nếu Android chặn, vào cài đặt cho phép cài ứng dụng từ nguồn bạn vừa dùng để mở APK. Chỉ cài APK do chính bạn build hoặc nguồn bạn tin cậy.

## Nếu chỉ có điện thoại Android
Có thể dùng AndroidIDE hoặc một môi trường build Android tương thích, nhưng thiết lập phức tạp hơn và không phải máy nào cũng build ổn. Cách dễ nhất là dùng máy tính có Android Studio hoặc nhờ người thân build APK từ chính mã nguồn này.

## Lưu ý về bản hiện tại
Đây là bản MVP, chưa phải ứng dụng đã phát hành. Điểm và danh sách chữ đã học hiện lưu trong trạng thái phiên chạy; đóng app có thể làm mất tiến độ. Vùng viết giúp luyện tay nhưng chưa tự nhận diện nét đúng/sai. Các phần này có thể được nâng cấp tiếp.


## Build APK tự động chỉ bằng điện thoại (GitHub Actions)

Cách này dùng GitHub để build trên máy chủ; điện thoại chỉ cần trình duyệt.

1. Đăng nhập hoặc tạo tài khoản tại https://github.com
2. Tạo repository mới, ví dụ `KanaMaster`, chọn **Public** hoặc **Private**, rồi tạo repository.
3. Trên trang repository, bấm **Add file → Upload files**. Tải lên toàn bộ nội dung dự án đã giải nén, bao gồm thư mục `.github` và tệp `.github/workflows/build-apk.yml`. Trên điện thoại có thể cần bật chế độ trang web cho máy tính để thấy đủ tùy chọn.
4. Commit các tệp lên nhánh `main`.
5. Mở tab **Actions** của repository. Chọn **Build Kana Master APK** rồi bấm **Run workflow** nếu workflow chưa tự chạy sau lần commit.
6. Chờ job màu xanh hoàn tất. Mở lần chạy đó, kéo xuống phần **Artifacts**, tải `KanaMaster-debug-APK` về và giải nén ZIP để lấy `app-debug.apk`.
7. Mở APK trên điện thoại để cài. Chỉ cài APK do chính repository của ông build; Android có thể yêu cầu cho phép cài ứng dụng từ trình duyệt/tệp tin mà ông dùng.

Lưu ý:
- Đây là **debug APK** để tự thử, chưa phải bản phát hành trên Google Play.
- APK được tạo từ mã nguồn trong repository. Không đưa mật khẩu, khóa ký hay dữ liệu cá nhân vào repository.
- GitHub Actions có giới hạn sử dụng miễn phí và giao diện trên điện thoại có thể khác đôi chút.
- Nếu build thất bại, mở log của job màu đỏ và gửi ảnh/lỗi cho trợ lý để sửa.
