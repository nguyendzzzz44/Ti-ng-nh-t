package com.example.kanamaster

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.random.Random

private val Bg = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Pink = Color(0xFFFF4F9A)
private val Blue = Color(0xFF527BFF)
private val Mint = Color(0xFF45E0B0)
private val Ink = Color(0xFFF4F6FF)
private val Muted = Color(0xFFA8B2C8)

data class Kana(val symbol: String, val sound: String, val group: String)

private val hira = listOf(
    Kana("あ","a","あ行"), Kana("い","i","あ行"), Kana("う","u","あ行"), Kana("え","e","あ行"), Kana("お","o","あ行"),
    Kana("か","ka","か行"), Kana("き","ki","か行"), Kana("く","ku","か行"), Kana("け","ke","か行"), Kana("こ","ko","か行"),
    Kana("さ","sa","さ行"), Kana("し","shi","さ行"), Kana("す","su","さ行"), Kana("せ","se","さ行"), Kana("そ","so","さ行"),
    Kana("た","ta","た行"), Kana("ち","chi","た行"), Kana("つ","tsu","た行"), Kana("て","te","た行"), Kana("と","to","た行"),
    Kana("な","na","な行"), Kana("に","ni","な行"), Kana("ぬ","nu","な行"), Kana("ね","ne","な行"), Kana("の","no","な行"),
    Kana("は","ha","は行"), Kana("ひ","hi","は行"), Kana("ふ","fu","は行"), Kana("へ","he","は行"), Kana("ほ","ho","は行"),
    Kana("ま","ma","ま行"), Kana("み","mi","ま行"), Kana("む","mu","ま行"), Kana("め","me","ま行"), Kana("も","mo","ま行"),
    Kana("や","ya","や行"), Kana("ゆ","yu","や行"), Kana("よ","yo","や行"),
    Kana("ら","ra","ら行"), Kana("り","ri","ら行"), Kana("る","ru","ら行"), Kana("れ","re","ら行"), Kana("ろ","ro","ら行"),
    Kana("わ","wa","わ行"), Kana("を","o","わ行"), Kana("ん","n","わ行")
)
private val kata = listOf(
    "ア:a","イ:i","ウ:u","エ:e","オ:o","カ:ka","キ:ki","ク:ku","ケ:ke","コ:ko",
    "サ:sa","シ:shi","ス:su","セ:se","ソ:so","タ:ta","チ:chi","ツ:tsu","テ:te","ト:to",
    "ナ:na","ニ:ni","ヌ:nu","ネ:ne","ノ:no","ハ:ha","ヒ:hi","フ:fu","ヘ:he","ホ:ho",
    "マ:ma","ミ:mi","ム:mu","メ:me","モ:mo","ヤ:ya","ユ:yu","ヨ:yo","ラ:ra","リ:ri",
    "ル:ru","レ:re","ロ:ro","ワ:wa","ヲ:o","ン:n"
).map { val p = it.split(":"); Kana(p[0],p[1],"Katakana") }

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPAN
        }
        setContent { KanaMasterApp(onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kana") }) }
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
fun KanaMasterApp(onSpeak: (String) -> Unit) {
    var tab by remember { mutableStateOf("Học chữ") }
    var script by remember { mutableStateOf("Hiragana") }
    var learned by remember { mutableStateOf(setOf<String>()) }
    var correct by remember { mutableIntStateOf(0) }
    var attempts by remember { mutableIntStateOf(0) }
    var quiz by remember { mutableStateOf(hira[0]) }
    var feedback by remember { mutableStateOf("") }
    var drawKey by remember { mutableIntStateOf(0) }
    val list = if (script == "Hiragana") hira else kata
    val progress = learned.size / 46f

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Pink, secondary = Blue,
        onBackground = Ink, onSurface = Ink
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
                Text("かな  KANA MASTER", color = Pink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("Chinh phục tiếng Nhật", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Text("Miễn phí • học từng bước • ngoại tuyến", color = Muted, fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Học chữ","Luyện viết","Trắc nghiệm","Tiến độ").forEach { name ->
                    val selected = tab == name
                    TextButton(
                        onClick = { tab = name },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColors(contentColor = if (selected) Pink else Muted)
                    ) { Text(name, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) }
                }
            }
            when (tab) {
                "Học chữ" -> LearnScreen(script, { script = it }, list, learned, { learned = learned + it }, onSpeak)
                "Luyện viết" -> WritingScreen(list.firstOrNull { it.symbol == quiz.symbol } ?: list[0], drawKey) { drawKey++ }
                "Trắc nghiệm" -> QuizScreen(quiz, { quiz = it }, list, onSpeak, { attempts++; if (it) correct++ }, feedback, { feedback = it })
                else -> ProgressScreen(learned.size, correct, attempts, learned)
            }
        }
    }
}

@Composable
fun ScriptPicker(script: String, onChange: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Hiragana","Katakana").forEach {
            val selected = script == it
            Button(onClick = { onChange(it) }, colors = ButtonDefaults.buttonColors(
                containerColor = if (selected) Pink else Panel, contentColor = Ink
            ), shape = RoundedCornerShape(12.dp)) { Text(it) }
        }
    }
}

@Composable
fun LearnScreen(script: String, onScript: (String) -> Unit, list: List<Kana>, learned: Set<String>,
                onLearn: (String) -> Unit, onSpeak: (String) -> Unit) {
    var selected by remember { mutableStateOf(list.first()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScriptPicker(script, onScript)
        Text("${if (script == "Hiragana") "Bảng Hiragana" else "Bảng Katakana"} • 46 chữ cơ bản", color = Muted, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(selected.symbol, color = Ink, fontSize = 88.sp, fontWeight = FontWeight.Medium)
                Text(selected.sound, color = Pink, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Chọn chữ trong bảng, nghe phát âm rồi đánh dấu đã học.", color = Muted, textAlign = TextAlign.Center, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onSpeak(selected.symbol) }) { Text("🔊 Nghe đọc") }
                    Button(onClick = { onLearn(selected.symbol) }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Bg)) {
                        Text(if (selected.symbol in learned) "Đã học ✓" else "Đánh dấu đã học")
                    }
                }
            }
        }
        LazyVerticalGrid(columns = GridCells.Fixed(5), modifier = Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            items(list) { kana ->
                val isSelected = kana.symbol == selected.symbol
                Card(onClick = { selected = kana }, colors = CardDefaults.cardColors(containerColor = if (isSelected) Pink.copy(alpha=.22f) else Panel),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Pink) else null,
                    shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(kana.symbol, fontSize = 25.sp, color = if (kana.symbol in learned) Mint else Ink)
                        Text(kana.sound, fontSize = 10.sp, color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
fun WritingScreen(kana: Kana, drawKey: Int, onClear: () -> Unit) {
    val strokes = remember(drawKey) { mutableStateListOf<List<Offset>>() }
    var current by remember(drawKey) { mutableStateOf(listOf<Offset>()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("LUYỆN VIẾT", color = Pink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("Tập viết bằng ngón tay", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Mẫu chữ: ${kana.symbol}  •  ${kana.sound}", color = Muted)
        Box(Modifier.fillMaxWidth().height(330.dp).border(1.dp, Blue, RoundedCornerShape(18.dp)).background(Panel, RoundedCornerShape(18.dp))) {
            Canvas(Modifier.fillMaxSize().pointerInput(drawKey) {
                detectDragGestures(onDragStart = { current = listOf(it) }, onDrag = { change, _ ->
                    current = current + change.position
                }, onDragEnd = { strokes.add(current); current = emptyList() })
            }) {
                val step = 52.dp.toPx()
                for (x in 0..(size.width / step).toInt()) drawLine(Color(0xFF273248), Offset(x*step,0f), Offset(x*step,size.height), 1f)
                for (y in 0..(size.height / step).toInt()) drawLine(Color(0xFF273248), Offset(0f,y*step), Offset(size.width,y*step), 1f)
                drawContext.canvas.nativeCanvas.let { canvas ->
                    val paint = android.graphics.Paint().apply { color = android.graphics.Color.argb(70,255,255,255); textSize = 220f; textAlign = android.graphics.Paint.Align.CENTER }
                    canvas.drawText(kana.symbol, size.width/2, size.height/2 + 70f, paint)
                }
                (strokes + listOf(current)).forEach { points ->
                    if (points.size > 1) {
                        val path = Path().apply { moveTo(points.first().x, points.first().y); points.drop(1).forEach { lineTo(it.x,it.y) } }
                        drawPath(path, Pink, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 8f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    }
                }
            }
        }
        Text("Tô theo chữ mờ để quen nét. Đây là vùng luyện tự do, chưa tự chấm độ chính xác.", color = Muted, fontSize = 12.sp)
        Button(onClick = onClear, colors = ButtonDefaults.buttonColors(containerColor = Blue), modifier = Modifier.fillMaxWidth()) { Text("Xóa nét và viết lại") }
    }
}

@Composable
fun QuizScreen(quiz: Kana, setQuiz: (Kana) -> Unit, list: List<Kana>, onSpeak: (String) -> Unit,
               onAnswer: (Boolean) -> Unit, feedback: String, setFeedback: (String) -> Unit) {
    var options by remember(quiz) { mutableStateOf((listOf(quiz) + list.filter { it.sound != quiz.sound }.shuffled().take(3)).shuffled()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("THỬ THÁCH KANA", color = Pink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Chữ này đọc như thế nào?", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(quiz.symbol, fontSize = 90.sp, color = Ink)
                TextButton(onClick = { onSpeak(quiz.symbol) }) { Text("🔊 Nghe phát âm") }
            }
        }
        options.forEach { option ->
            OutlinedButton(onClick = {
                val ok = option.sound == quiz.sound
                setFeedback(if (ok) "Chính xác! +1 điểm ✨" else "Chưa đúng rồi. Đáp án: ${quiz.sound}")
                onAnswer(ok)
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)) {
                Text(option.sound, fontSize = 18.sp)
            }
        }
        if (feedback.isNotBlank()) Text(feedback, color = if (feedback.startsWith("Chính")) Mint else Pink, fontWeight = FontWeight.Bold)
        Button(onClick = { setQuiz(list.random()); setFeedback("") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Pink)) { Text("Câu tiếp theo") }
    }
}

@Composable
fun ProgressScreen(learnedCount: Int, correct: Int, attempts: Int, learned: Set<String>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("HÀNH TRÌNH CỦA BẠN", color = Pink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Mỗi ngày tiến một chút 🇯🇵", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Đã học", "$learnedCount / 92", Modifier.weight(1f))
            StatCard("Điểm đúng", "$correct", Modifier.weight(1f))
            StatCard("Lượt làm", "$attempts", Modifier.weight(1f))
        }
        LinearProgressIndicator(progress = { learnedCount / 92f }, modifier = Modifier.fillMaxWidth(), color = Mint, trackColor = Panel)
        Text("Tiến độ đánh dấu học: ${learnedCount * 100 / 92}%", color = Muted)
        Text("Chữ đã đánh dấu", color = Ink, fontWeight = FontWeight.Bold)
        Text(if (learned.isEmpty()) "Chưa có chữ nào. Vào mục Học chữ và đánh dấu sau khi ôn nhé!" else learned.joinToString("  "), color = Mint, fontSize = 20.sp)
        Text("Mẹo: học 5–10 chữ mỗi ngày, ngày hôm sau ôn lại trước khi học mới.", color = Muted)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Pink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Text(label, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}
